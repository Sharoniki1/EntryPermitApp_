package com.example.entrypermitapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.os.BatteryManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private TextInputEditText main_EDT_password;
    private MaterialButton main_BTN_login;

    private SensorManager sensorManager;
    private Sensor magneticSensor;
    private Sensor accelerometerSensor;
    private float[] magneticValues = new float[3];
    private float[] accelerometerValues = new float[3];
    private int batteryLevel;
    private float northOrientation;
    private AudioManager audioManager;
    private static final int NOISY_SOUND_LEVEL = 80;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViews();

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        magneticSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        audioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        main_BTN_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onLoginButtonClick(v);
            }
        });
    }

    private void findViews() {
        main_EDT_password = findViewById(R.id.main_EDT_password);
        main_BTN_login = findViewById(R.id.main_BTN_login);
    }

    @Override
    protected void onResume() {
      super.onResume();
      sensorManager.registerListener((SensorEventListener) this, magneticSensor, SensorManager.SENSOR_DELAY_NORMAL);
      sensorManager.registerListener((SensorEventListener) this, accelerometerSensor, SensorManager.SENSOR_DELAY_NORMAL);
      batteryLevel = getBatteryLevel();
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener((SensorEventListener) this, magneticSensor);
        sensorManager.unregisterListener((SensorEventListener) this, accelerometerSensor);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
            magneticValues = event.values.clone();
        } else if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            accelerometerValues = event.values.clone();
        }

        float[] rotationMatrix = new float[9];
        boolean success = SensorManager.getRotationMatrix(rotationMatrix, null, accelerometerValues, magneticValues);
        if (success) {
            float[] orientationValues = new float[3];
            SensorManager.getOrientation(rotationMatrix, orientationValues);
            float azimuth = (float) Math.toDegrees(orientationValues[0]);
            if (azimuth < 0) {
                azimuth += 360;
            }
            northOrientation = Math.round(azimuth);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Do nothing
    }

    private int getBatteryLevel() {
        Intent batteryIntent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        return Math.round((float) level / (float) scale * 100.0f);
    }


    private void onLoginButtonClick(View view) {
        String password = main_EDT_password.getText().toString();
        int roundedNorthOrientation = Math.round(northOrientation);
        int ringerMode = audioManager.getRingerMode();
        int currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_RING);

        if (password.equals(String.valueOf(batteryLevel)) &&
                (roundedNorthOrientation >= 0 && roundedNorthOrientation <= 45 ||
                        roundedNorthOrientation >= 315 && roundedNorthOrientation <= 360 &&

                                currentVolume >= NOISY_SOUND_LEVEL)) {
            // Password matches battery level and north orientation, do something
            Intent intent = new Intent(MainActivity.this, EntryPermitActivity.class);
            startActivity(intent);
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
        } else {
            // Password is incorrect, show error message
            Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
        }
    }
}